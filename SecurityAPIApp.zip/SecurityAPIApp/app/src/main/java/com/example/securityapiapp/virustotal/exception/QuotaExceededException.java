package com.example.securityapiapp.virustotal.exception;

public class QuotaExceededException extends Exception{
    public QuotaExceededException() {
    }

    public QuotaExceededException(String string) {
        super(string);
    }

    public QuotaExceededException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public QuotaExceededException(Throwable thrwbl) {
        super(thrwbl);
    }
}
