package com.example.securityapiapp.virustotal.exception;

public class InvalidArguentsException extends Exception{
    public InvalidArguentsException() {
    }

    public InvalidArguentsException(String string) {
        super(string);
    }

    public InvalidArguentsException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public InvalidArguentsException(Throwable thrwbl) {
        super(thrwbl);
    }

}
