package com.example.securityapiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.securityapiapp.virustotal.dto.ScanInfo;
import com.example.securityapiapp.virustotal.exception.APIKeyNotFoundException;
import com.example.securityapiapp.virustotal.exception.UnauthorizedAccessException;
import com.example.securityapiapp.virustotalv2.VirusTotalConfig;
import com.example.securityapiapp.virustotalv2.VirustotalPublicV2;
import com.example.securityapiapp.virustotalv2.VirustotalPublicV2Impl;

import java.io.UnsupportedEncodingException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    Button button;
    EditText et_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //assigning values
        button  = findViewById(R.id.button);
        et_message = findViewById(R.id.et_message);
        EditText editText=findViewById(R.id.et_message);
        String value=editText.getText().toString();
        TextView textView = findViewById(R.id.textOut);

        //result = (TextView) findViewById(R.id.tvResult);
        //textView.setText(R.string.user_greeting);


        // click listeners
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StringBuffer sbf3;

                Toast.makeText(MainActivity.this, "You typed " + et_message.getText().toString(), Toast.LENGTH_SHORT).show();
                //Toast.makeText(MainActivity.this, "Urls Found " + extractUrl(et_message), Toast.LENGTH_SHORT).show();
                List<String> linkf = extractUrls(value);
                String joined = TextUtils.join(", ", linkf);
                //scanUrl();
                textView.setText(joined);
                //Toast.makeText(MainActivity.this, "yayy " + et_message.getText().toString(), Toast.LENGTH_SHORT).show();


            }

            public List<String> extractUrls(String text)
            {
                List<String> containedUrls = new ArrayList<String>();
                String urlRegex = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
                Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
                Matcher urlMatcher = pattern.matcher(text);

                while (urlMatcher.find())
                {
                    containedUrls.add(text.substring(urlMatcher.start(0),
                            urlMatcher.end(0)));
                }

                return containedUrls;
            }
            /*public StringBuffer extractUrl(String string) {

                List<String> list = new ArrayList<>();
                StringBuffer sbf2 = new StringBuffer("Empty Text");
                String regexString = "\\b(https://|www[.])[A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]";
                Pattern pattern = Pattern.compile(regexString,Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(string);
                while (matcher.find()) {
                    list.add(string.substring(matcher.start(0),matcher.end(0)));
                }
                if (list.size() ==0) {
                   System.out.println("Empty list");
                }
                for(String str:list)
                {
                    System.out.println(str);
                    sbf2.append(str);
                }
                return sbf2;

            }*/

            public void scanUrl() {
                try {
                    VirusTotalConfig.getConfigInstance().setVirusTotalAPIKey("APIKEY");
                    VirustotalPublicV2 virusTotalRef = new VirustotalPublicV2Impl();

                    String urls[] = {"www.google.lk", "www.yahoo.com"};
                    ScanInfo[] scanInfoArr = virusTotalRef.scanUrls(urls);
                    StringBuffer sbf1 = new StringBuffer("___SCAN INFORMATION___");

                    for (ScanInfo scanInformation : scanInfoArr) {
                        sbf1.append("MD5 :\t" + scanInformation.getMd5() + sbf1);
                        sbf1.append("Perma Link :\t" + scanInformation.getPermalink()+ sbf1);
                        sbf1.append("Resource :\t" + scanInformation.getResource()+ sbf1);
                        //System.out.println("Scan Date :\t" + scanInformation.getScan_date());
                        //System.out.println("Scan Id :\t" + scanInformation.getScan_id());
                        sbf1.append("SHA1 :\t" + scanInformation.getSha1()+ sbf1);
                        sbf1.append("SHA256 :\t" + scanInformation.getSha256()+ sbf1);
                        //System.out.println("Verbose Msg :\t" + scanInformation.getVerbose_msg());
                        //System.out.println("Response Code :\t" + scanInformation.getResponse_code());
                        sbf1.append("done."+ sbf1);
                        textView.setText(sbf1);
                    }

                } catch (APIKeyNotFoundException ex) {
                    System.err.println("API Key not found! " + ex.getMessage());
                } catch (UnsupportedEncodingException ex) {
                    System.err.println("Unsupported Encoding Format!" + ex.getMessage());
                } catch (UnauthorizedAccessException ex) {
                    System.err.println("Invalid API Key " + ex.getMessage());
                } catch (Exception ex) {
                    System.err.println("Something Bad Happened! " + ex.getMessage());
                }
            }
        });


    }


}

