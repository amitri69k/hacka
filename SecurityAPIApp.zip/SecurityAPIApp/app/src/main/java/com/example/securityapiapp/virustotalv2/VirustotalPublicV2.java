package com.example.securityapiapp.virustotalv2;

import com.example.securityapiapp.virustotal.dto.DomainReport;
import com.example.securityapiapp.virustotal.dto.FileScanReport;
import com.example.securityapiapp.virustotal.dto.GeneralResponse;
import com.example.securityapiapp.virustotal.dto.IPAddressReport;
import com.example.securityapiapp.virustotal.dto.ScanInfo;
import com.example.securityapiapp.virustotal.exception.InvalidArguentsException;
import com.example.securityapiapp.virustotal.exception.QuotaExceededException;
import com.example.securityapiapp.virustotal.exception.UnauthorizedAccessException;

import java.io.File;
import java.io.IOException;

public interface VirustotalPublicV2 {
    String URI_VT2_FILE_SCAN = "https://www.virustotal.com/vtapi/v2/file/scan";
    String URI_VT2_RESCAN = "https://www.virustotal.com/vtapi/v2/file/rescan";
    String URI_VT2_FILE_SCAN_REPORT = "https://www.virustotal.com/vtapi/v2/file/report";
    String URI_VT2_URL_SCAN = "https://www.virustotal.com/vtapi/v2/url/scan";
    String URI_VT2_URL_SCAN_REPORT = "http://www.virustotal.com/vtapi/v2/url/report";
    String URI_VT2_IP_REPORT = "http://www.virustotal.com/vtapi/v2/ip-address/report";
    String URI_VT2_DOMAIN_REPORT = "http://www.virustotal.com/vtapi/v2/domain/report";
    String URI_VT2_PUT_COMMENT = "https://www.virustotal.com/vtapi/v2/comments/put";
    String VT2_URLSEPERATOR = "\n";
    int VT2_MAX_ALLOWED_URLS_PER_REQUEST = 4;


    ScanInfo[] scanUrls(final String[] urls) throws IOException, UnauthorizedAccessException, QuotaExceededException, InvalidArguentsException;

    /**
     * Returns the detailed scan report for given set of urls
     *
     * @param url  set of urls
     * @param scan true if url s must be scanned before generating the report
     * @return
     */
    FileScanReport[] getUrlScanReport(final String[] url, boolean scan) throws IOException, UnauthorizedAccessException, QuotaExceededException, InvalidArguentsException;

    /**
     * Returns detailed report for a given IP
     *
     * @param ipAddress a valid IPv4 address in dotted quad notation, for the time being only IPv4 addresses are supported.
     * @return
     */
    IPAddressReport getIPAddresReport(final String ipAddress) throws InvalidArguentsException, QuotaExceededException, UnauthorizedAccessException, IOException;

    /**
     * Returns a detailed report for a given domain
     *
     * @param domain domain name
     * @return
     */
    DomainReport getDomainReport(final String domain) throws InvalidArguentsException, UnauthorizedAccessException, QuotaExceededException, IOException;

    /**
     * @param resource either a md5/sha1/sha256 hash of the file you want to review or the URL itself that you want to comment on.
     * @param comment  the actual review, you can tag it using the "#" twitter-like syntax (e.g. #disinfection #zbot)
     *                 and reference users using the "@" syntax (e.g. @VirusTotalTeam).
     * @return
     */
    GeneralResponse makeAComment(final String resource, final String comment) throws IOException, UnauthorizedAccessException, InvalidArguentsException, QuotaExceededException;


}
