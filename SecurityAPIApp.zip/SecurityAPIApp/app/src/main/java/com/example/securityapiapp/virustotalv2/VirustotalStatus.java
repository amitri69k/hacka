package com.example.securityapiapp.virustotalv2;

import java.net.HttpURLConnection;

public final class VirustotalStatus {

    private VirustotalStatus() {
    }
    public static final int FORBIDDEN = HttpURLConnection.HTTP_FORBIDDEN;
    public static final int API_LIMIT_EXCEEDED = HttpURLConnection.HTTP_NO_CONTENT;
    public static final int SUCCESSFUL = HttpURLConnection.HTTP_OK;
}
