package com.example.securityapiapp.net.exception;

import com.example.securityapiapp.net.model.HttpStatus;

public class RequestNotComplete extends Exception{
    private HttpStatus httpStatus;

    public RequestNotComplete(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public RequestNotComplete(String message, HttpStatus httpStatus) {
        super(message);
        this.httpStatus = httpStatus;
    }

    public RequestNotComplete(String message, Throwable cause, HttpStatus httpStatus) {
        super(message, cause);
        this.httpStatus = httpStatus;
    }

    public RequestNotComplete(Throwable cause, HttpStatus httpStatus) {
        super(cause);
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

}
