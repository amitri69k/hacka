package com.example.urlsafe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.safetynet.SafeBrowsingThreat;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

/*public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}*/



class ThreatList extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_threat, container, false);

        new LoadThreatData().execute();
        return view;
    }

    @Override
    public void onResume(){
        super.onResume();
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadThreatData extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            SafetyNet.getClient(getActivity()).initSafeBrowsing();
            Log.d("Threats", "init");

            return null;
        }

        @Override
        protected void onPostExecute(Void result){
            String url = "http://malware.testing.google.test/testing/malware/"; //"go.trackmyclicks202.com";//"http://ianfette.org/"; //"http://malware.wicar.org/data/eicar.com";

            SafetyNet.getClient(getActivity()).lookupUri(
                    url,
                    "AIzaSyAX0WgJ1GZ7wiK0rDsLGUcTA9a_3L3Jns4",
                    SafeBrowsingThreat.TYPE_POTENTIALLY_HARMFUL_APPLICATION,
                    SafeBrowsingThreat.TYPE_SOCIAL_ENGINEERING)
                    .addOnSuccessListener(getActivity(), new OnSuccessListener<SafetyNetApi.SafeBrowsingResponse>() {
                        @Override
                        public void onSuccess(SafetyNetApi.SafeBrowsingResponse sbResponse) {
                            // Indicates communication with the service was successful.
                            // Identify any detected threats.
                            if (sbResponse.getDetectedThreats().isEmpty()) {
                                // No threats found.
                                Log.e("Threats", "no threats found");
                                Toast.makeText(
                                        getActivity(),
                                        "no threats",
                                        Toast.LENGTH_SHORT)
                                        .show();

                                //always get in here
                            } else {
                                // Threats found!
                                Log.e("Threats", sbResponse.toString());
                                Toast.makeText(
                                        getActivity(),
                                        sbResponse.toString(),
                                        Toast.LENGTH_SHORT)
                                        .show();
                            }
                        }
                    })
                    .addOnFailureListener(getActivity(), new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // An error occurred while communicating with the service.
                            if (e instanceof ApiException) {
                                // An error with the Google Play Services API contains some
                                // additional details.
                                ApiException apiException = (ApiException) e;
                                Log.d("hello", "Error: " + CommonStatusCodes
                                        .getStatusCodeString(apiException.getStatusCode()));
                                Toast.makeText(
                                        getActivity(),
                                        "error1",
                                        Toast.LENGTH_SHORT)
                                        .show();

                                // Note: If the status code, apiException.getStatusCode(),
                                // is SafetyNetstatusCode.SAFE_BROWSING_API_NOT_INITIALIZED,
                                // you need to call initSafeBrowsing(). It means either you
                                // haven't called initSafeBrowsing() before or that it needs
                                // to be called again due to an internal error.
                            } else {
                                // A different, unknown type of error occurred.
                                Log.d("hello", "Error: " + e.getMessage());
                                Toast.makeText(
                                        getActivity(),
                                        "error2",
                                        Toast.LENGTH_SHORT)
                                        .show();
                            }
                        }
                    });

        }
    }
}