package com.example.securityapiapp.virustotal.exception;

public class APIKeyNotFoundException extends Exception{
    public APIKeyNotFoundException() {
    }

    public APIKeyNotFoundException(String string) {
        super(string);
    }

    public APIKeyNotFoundException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public APIKeyNotFoundException(Throwable thrwbl) {
        super(thrwbl);
    }

}
