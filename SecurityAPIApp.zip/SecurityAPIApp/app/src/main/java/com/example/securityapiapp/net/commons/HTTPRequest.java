/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.securityapiapp.net.commons;

import com.example.securityapiapp.net.exception.RequestNotComplete;
import com.example.securityapiapp.net.model.FormData;
import com.example.securityapiapp.net.model.Header;
import com.example.securityapiapp.net.model.MultiPartEntity;
import com.example.securityapiapp.net.model.RequestMethod;
import com.example.securityapiapp.net.model.Response;

import java.io.IOException;
import java.util.List;

/**
 * @author kdkanishka@gmail.com
 */
public interface HTTPRequest {

    Response request(String urlStr, List<Header> reqHeaders,
                     List<FormData> formData,
                     RequestMethod requestMethod,
                     List<MultiPartEntity> multiParts) throws
            RequestNotComplete, IOException;
}
