package com.example.securityapiapp.virustotal.exception;

public class UnauthorizedAccessException extends Exception{
    public UnauthorizedAccessException() {
    }

    public UnauthorizedAccessException(String string) {
        super(string);
    }

    public UnauthorizedAccessException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public UnauthorizedAccessException(Throwable thrwbl) {
        super(thrwbl);
    }
}
