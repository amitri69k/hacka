/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.securityapiapp.net.model;

/**
 *
 * @author kdkanishka@gmail.com
 */
public enum RequestMethod {

    GET, POST, PUT, DELETE
}
