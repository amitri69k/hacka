package com.example.securityapiapp.virustotal.dto;

import com.google.gson.annotations.SerializedName;

public class DomainResolution {
    @SerializedName("last_resolved")
    private String lastResolved;
    @SerializedName("ip_address")
    private String ipAddress;

    public String getLastResolved() {
        return lastResolved;
    }

    public void setLastResolved(String lastResolved) {
        this.lastResolved = lastResolved;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
}
