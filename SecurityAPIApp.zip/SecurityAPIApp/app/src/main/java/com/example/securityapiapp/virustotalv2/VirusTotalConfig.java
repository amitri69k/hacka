package com.example.securityapiapp.virustotalv2;

public final class VirusTotalConfig {

    private String virusTotalAPIKey;
    private static VirusTotalConfig configInstance = null;

    private VirusTotalConfig() {
        virusTotalAPIKey = "54ea9f678965b6742ae1063eeca47ae01e6551ae4375c3c220660069e2139542";
    }

    public static VirusTotalConfig getConfigInstance() {
        if (configInstance == null) {
            synchronized (VirusTotalConfig.class) {
                if (configInstance == null) {
                    configInstance = new VirusTotalConfig();
                }
            }
        }
        return configInstance;
    }

    public String getVirusTotalAPIKey() {
        return virusTotalAPIKey;
    }

    public void setVirusTotalAPIKey(String virusTotalAPIKey) {
        this.virusTotalAPIKey = virusTotalAPIKey;
    }

}

